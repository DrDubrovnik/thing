A feed forward neural network that will teach a 2D AI agent to walk over the course of roughly 50 generations.
